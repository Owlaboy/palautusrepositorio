# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

modules = \
['project_reader']
install_requires = \
['toml>=0.10.2,<0.11.0']

setup_kwargs = {
    'name': 'project-reader',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Kalle Ilves',
    'author_email': 'kalle.ilves@helsinki.fi',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'py_modules': modules,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
